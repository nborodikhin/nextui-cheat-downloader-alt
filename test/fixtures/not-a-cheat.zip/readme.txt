not a cheat archive
